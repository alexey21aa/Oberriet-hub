<?php
namespace OberHubV6\AI;
/** Server-only credentials, fixed provider endpoints and bounded free-plan usage. */
final class ProviderSettings {
 public static function boot():void {
  add_action('admin_menu',fn()=>add_options_page('OberHub server AI','OberHub server AI','manage_options','oberhub-server-ai',[self::class,'render']));
  add_action('admin_post_oh_v8_ai_settings',[self::class,'save']);
 }
 public static function config():array {return get_option('oh_v8_provider_settings',[]);}
 public static function save():void {
  if(!current_user_can('manage_options'))wp_die('Forbidden');check_admin_referer('oh_v8_ai_settings');$old=self::config();$next=[];
  foreach(['cf_key','groq_key','tavily_key'] as $field){$v=trim((string)wp_unslash($_POST[$field]??''));$next[$field]=$v!==''?$v:($old[$field]??'');}
  $id=sanitize_text_field(wp_unslash($_POST['cf_account']??''));if($id!==''&&!preg_match('/^[a-f0-9]{32}$/i',$id))wp_die('Invalid Cloudflare account ID');$next['cf_account']=$id;
  $next['enabled']=!empty($_POST['free_plan_only']);update_option('oh_v8_provider_settings',$next,false);update_option('oh_ai_config_version',(string)microtime(true),false);
  wp_safe_redirect(admin_url('options-general.php?page=oberhub-server-ai&saved=1'));exit;
 }
 public static function providers():array {
  $c=self::config();$out=[];
  if(!empty($c['enabled'])){
   if(!empty($c['cf_key'])&&preg_match('/^[a-f0-9]{32}$/i',$c['cf_account']??''))$out[]=['enabled'=>true,'free_tier'=>true,'id'=>'cloudflare','endpoint'=>'https://api.cloudflare.com/client/v4/accounts/'.$c['cf_account'].'/ai/v1/chat/completions','key'=>$c['cf_key'],'model'=>'@cf/openai/gpt-oss-20b'];
   if(!empty($c['groq_key']))$out[]=['enabled'=>true,'free_tier'=>true,'id'=>'groq','endpoint'=>'https://api.groq.com/openai/v1/chat/completions','key'=>$c['groq_key'],'model'=>'openai/gpt-oss-20b'];
  }
  $legacy=defined('OBERHUB_AI_PROVIDERS')?OBERHUB_AI_PROVIDERS:[];return array_merge($out,is_array($legacy)?$legacy:[]);
 }
 public static function reserve(string $provider,int $minute,int $maximum,string $period='day'):bool {
  $lock='oh_v8_quota_lock_'.$provider;if(!add_option($lock,time(),'','no')){if((int)get_option($lock,0)<time()-30)delete_option($lock);return false;}
  try {
   $key='oh_v8_usage_'.$provider;$v=get_option($key,[]);$date=gmdate($period==='month'?'Y-m':'Y-m-d');$min=(int)floor(time()/60);
   if(($v['period']??'')!==$date)$v=['period'=>$date,'count'=>0];if(($v['minute']??0)!==$min){$v['minute']=$min;$v['minute_count']=0;}
   if(($v['count']??0)>=$maximum||($v['minute_count']??0)>=$minute)return false;
   $v['count']++;$v['minute_count']++;update_option($key,$v,false);return true;
  }finally{delete_option($lock);}
 }
 public static function status():array {$p=self::providers();$c=self::config();return ['generative_configured'=>(bool)array_filter($p,fn($p)=>!empty($p['enabled'])&&!empty($p['free_tier'])),'generative_success_at'=>get_option('oh_v8_ai_success_at',null),'providers'=>array_map(fn($p)=>$p['id']??'operator-provider',$p),'live_geo_fallback'=>true,'live_web_configured'=>!empty($c['enabled'])&&!empty($c['tavily_key']),'cached_discoveries'=>count(array_filter(get_option('oh_v8_cached_discovery_ids',[]),fn($expires)=>$expires>time()))];}
 public static function render():void {
  if(!current_user_can('manage_options'))return;$c=self::config();echo '<div class="wrap"><h1>OberHub — Free server AI / live search</h1><p>Use free-plan accounts only. Secrets remain on the WordPress server. Blank key fields preserve existing keys. Daily inference cap: 200 calls per provider; Tavily cap: 900 basic searches/month. Provider free quotas may stop earlier; retrieval and evidence answers continue.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="oh_v8_ai_settings">';wp_nonce_field('oh_v8_ai_settings');
  echo '<p><label>Cloudflare Account ID <input name="cf_account" value="'.esc_attr($c['cf_account']??'').'"></label></p>';
  foreach(['cf_key'=>'Cloudflare Workers AI token','groq_key'=>'Groq API key (optional failover)','tavily_key'=>'Tavily API key (optional live web)'] as $key=>$label)echo '<p><label>'.esc_html($label).' <input type="password" name="'.esc_attr($key).'" value="" autocomplete="new-password"></label> '.(!empty($c[$key])?'Configured':'Not configured').'</p>';
  echo '<p><label><input type="checkbox" name="free_plan_only" value="1" '.checked(!empty($c['enabled']),true,false).'> These are free-plan accounts; enable server inference and web search.</label></p><button class="button button-primary">Save</button></form><p><a href="https://dash.cloudflare.com/">Cloudflare</a> · <a href="https://console.groq.com/keys">Groq</a> · <a href="https://app.tavily.com/">Tavily</a></p></div>';
 }
}
